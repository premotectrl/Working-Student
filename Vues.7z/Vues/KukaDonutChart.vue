<template>
    <div style="display: inline-block;">
        <span id="chart-title">{{ title }}</span>
        <div style="display: flex; align-items: center;">
            <div id="chart-container">
                <canvas class="donut-chart" width="150" height="150" :id="chartId"></canvas>
                <img v-if="icon" class="donut-icon" :src="icon">
            </div>
            <slot v-if="hideLegend" name="legend" style="display: inline-block; height: 100%"></slot>
            <div class="legend-table" v-if="!hideLegend">
                <table align="left">
                    <tr v-for="(label, index) in labels" :key="index">
                        <td>
                            <div v-if="!Array.isArray(legendIcons) || !legendIcons.length" class="legend-table-color" :style="{ backgroundColor: colors[index] }"></div>
                            <div v-else class="legend-table-icon">
                                <img :src="legendIcons[index]">
                            </div>
                        </td>
                        <td class="legend-table-value">{{dataPoints[index]}}{{displayUnit(index)}}</td>
                        <td class="legend-table-label">{{ label }}</td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</template>

<script>
    import Chart from 'chart.js';
    import {GUID} from './utils/utils';

    const updateGraph = (chart, data) => {
            Object.assign(chart.config.data.datasets[0].data, data);
            chart.update();
        };

    export default {
        name: "kuka-donut-chart",
        props: {
            title: String,
            hideLegend: Boolean,

            labels: Array,
            dataPoints: Array,  // An array of integers.
            colors: Array,

            // An optional array of Strings. If set, an icon will be displayed in front of the value instead of a colored
            // dot.
            legendIcons: Array,

            // An optional icon to be displayed at the center of the donut.
            icon: {
                type: String,
                default: null
            },

            // The symbol to display after a value, if @showUnit is set to `true` and the value does not require a
            // singular form.
            unit: {
                typre: String,
                default: '%'
            },

            // The symbol to display after a value, if @showUnit is set to `true` and the value requires a singular form.
            unitSingle: {
                type: String,
                default: '%'
            },

            // If true, a unit (@unit or @unitSingle) will be displayed after the value.
            showUnit: {
                type: Boolean,
                default: true
            }
        },
        data() {
            return {
                id: null,
                options: {
                    cutoutPercentage: 70,
                    animation: {
                        animateRotate: false,
                        animateScale: false,
                    },
                    responsive: false,
                    legend: {
                        display: false,
                    },
                    tooltips: {
                        enabled: false,
                    },
                },
                donut: null,
                displayColors: this.colors ? this.colors : ['#6EC8A0', '#CF2027',
                                                            '#285885', '#9F547D',
                                                            '#FFCD00', '#FF5800'],
            };
        },
        computed: {
            chartId() {
                if (!this.id) {
                    this.id = GUID();
                }
                return this.id;
            },
        },
        methods: {
            displayUnit (index) {
                if (this.showUnit === true) {
                    if (this.unitSingle && this.dataPoints[index] === 1) {
                        return this.unitSingle;
                    }
                    return this.unit;
                }
                return "";
            },
        },
        mounted() {
            const ctx = document.getElementById(this.chartId).getContext('2d');
            const config = {
                type: 'doughnut',
                data: {
                    datasets: [{
                        data: this.dataPoints,
                        backgroundColor: this.displayColors,
                        borderWidth: [0, 0, 0, 0, 0],
                    }],
                    labels: this.labels
                },
                options: this.options,
            };
            this.donut = new Chart(ctx, config);
            this.donut.update();
        },
        watch: {
            dataPoints: {
                handler: function(data) {
                    updateGraph(this.donut, data);
                },
                deep: true,
            },
        },
    }
</script>

<style lang="scss" scoped>
    @import "styles/variables";

    #chart-title {
        display: inline-block;
        margin-bottom: 30px;
        font-family: kuka-bulo-bold;
    }

    #chart-container {
        display: inline-block;
        margin-right: 18px;

        position: relative;
        justify-content: center;
        align-items: center;
    }

    .legend-table {
        display: inline-block;
        height: 100%;
        color: $kukaGrayForTypography;
        font-size: $standardFontSize;
        td {
            padding: 1px 4px 1px 4px;
        }
        &-value {
            font-family: kuka-bulo-bold;
        }
        &-color {
            width: 13px;
            height: 13px;
            border-radius: 50%;
            margin-right: 3px;
        }
    }

    .donut-icon {
        position: absolute;
        width: 22%;
        height: 22%;
        z-index: -1;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        margin: auto;
    }

    .legend-table-icon {
        height: $largeIconSize;
        width: $largeIconSize;
        border-radius: 50%;
        position: relative;
        display: inline-block;
        vertical-align: top;
    }

</style>
