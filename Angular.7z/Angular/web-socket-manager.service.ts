import { Injectable } from '@angular/core';
import {Observable} from 'rxjs/Rx';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class WebSocketManager {
  constructor() { }
  private source: Observable<MessageEvent>;

  public open(url) {
    console.log("openning for Asset: " + url);
  }

  public setupNewConnection(managerConfig): Observable<MessageEvent>{
    //singleton
    if (!this.source) {
      let ws = new WebSocket(managerConfig.url);
      ws.binaryType = <string>managerConfig.websocketOptions.binaryType;
      
      let psource = Observable.create(
        obs => {
          //onMessage receives data from the socket
          ws.onmessage = (event) => obs.next(event.data);
          ws.onerror = obs.error.bind(obs);
          ws.onclose = obs.complete.bind(obs);
          return ws.close.bind(obs);
        }
      );
      if (psource)
        return psource;
      else{
        console.log("P > No valid Object:");
        managerConfig.onError();//this the method call of the  main caller i.e app component
      }
    }
  }
}
