import { Injectable, OnInit } from '@angular/core';
import { Observable, Subject, ReplaySubject } from 'rxjs/Rx';
import { WebSocketManager } from './web-socket-manager.service';
import * as protobuf from 'protobufjs';

const Msg_URL = 'wss://www-dev.kuka-atx.com/api/operationalData/operationalDataOut/proto/980320';
var asssetId: Number;

@Injectable()
export class OperationalDataService {

	private source: Observable<MessageEvent>;
	public baseUrl = 'wss://www-dev.kuka-atx.com/api/operationalData/operationalDataOut/proto/';
	public parser: Subject<any> = new ReplaySubject(1);
	public parser$: Observable<any> = this.parser.asObservable();

	constructor(private WebSocketManager: WebSocketManager) {	
		let rooter = new protobuf.Root({ convertFieldsToCamelCase: true });
		rooter.resolvePath = function (origin, target) {
			return 'assets/proto/' + target;
		};
		protobuf.load('/kuka/api/operational.proto', rooter, (error, root) => {
			console.log(root)
			if (rooter) {
				this.parser.next(rooter.lookupType('kuka.api.OperationalData'));
			}
		});
	}

	ngOnInit() {
	}

	public get(assetId: number): Observable<any> {
		let dataIn:any;
		return this.connect(assetId).combineLatest(this.parser$, (rawData, parser) =>{ 
			return dataIn = parser.decode(new Uint8Array(rawData));
		});
	}

	private connect(assetId): Observable<any> {
		let url = this.baseUrl+assetId
		console.log(url);
		if (!this.source) {
			let ws = new WebSocket(url);
			ws.binaryType = 'arraybuffer';
			let source = Observable.create(
				obs => {
					ws.onmessage = (event) => obs.next(event.data);
					ws.onerror = obs.error.bind(obs);
					ws.onclose = obs.complete.bind(obs);
					return ws.close.bind(obs);
				});
			return source;
		}
	}
}