import { Component, OnDestroy, Injectable, OnInit } from '@angular/core';
import { OperationalDataService } from './operational-data.service';

interface AGV {
  processData: String;
  deviceId: {
    entityId: String;
    serialNumber: String
  }
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

export class AppComponent implements OnInit {
  assetId: string = '980320';
  dataIn: any;
  newAVG: AGV;

  constructor(private opDataService: OperationalDataService) {
    opDataService.get(this.assetId).subscribe(avg => {
      this.newAVG = avg;
    });

  }
  ngOnInit() { }

}
