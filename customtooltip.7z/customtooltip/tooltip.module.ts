import { NgModule } from '@angular/core';
import { CommonModule} from '@angular/common'
import {TooltipDirectiveDirective} from '../directives/tooltip-directive.directive';

@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [
        TooltipDirectiveDirective
    ],
    exports: [
        TooltipDirectiveDirective
    ]
})
export class TooltipModule{}