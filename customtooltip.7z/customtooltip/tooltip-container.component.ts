import { Component, OnInit , AfterViewInit, ElementRef, Inject} from '@angular/core';
import {TootipServiceService} from '../services/tootip-service.service';
import {TooltipComponent} from './tooltip.component'

@Component({
  selector: 'tooltip-container',
 
  template: 
  `
        <div class="tooltip-container" [ngStyle]="{'left': position}">
          <tooltip-content
            *ngFor="let tooltip of tooltipService.components"
            [title]="tooltip.title"
            [ref]="tooltip.ref">
          </tooltip-content>
        </div>
  `,
  styles: [
    `
        .tooltip-container{
          /* background-color: turquoise;*/
           /*left: 40px;
          right:0; */
          margin: -120px 0 0 0;
          /*float: right;
          top: 40px; */ /** minus height of element: to place above it vertically */
          /*padding: 5px; */
          display: inline-block;
          position: absolute;
          z-index: 20000; 
        }
    `
  ],
})
export class TooltipContainerComponent implements OnInit {
  position: any ="";// ="-40px";
  horizontAdjust: any= 230; // use the boundingRect: right-left -> width..
  constructor(public tooltipService: TootipServiceService, private contRef: ElementRef, @Inject('tooltipConfig') private config) { }
  
  ngOnInit() {
    let coord = this.config.host.getBoundingClientRect();
    //const {height} = this.contRef.nativeElement.getBoundingClientRect();
    let tooltip = this.contRef.nativeElement.getBoundingClientRect();
    //this.position = `${top + height}px`;
    this.position = (coord.right -  this.horizontAdjust) +"px";
   
    console.log(this.position);
  }
}

