import { Injectable } from '@angular/core';

@Injectable()
export class TootipServiceService {
  components: any[] = [];  
}
