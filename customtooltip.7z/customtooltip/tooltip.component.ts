import { Component, OnInit, Input, HostListener, AfterViewInit ,ViewChild} from '@angular/core';
import {TooltipContainerComponent} from './tooltip-container.component'

@Component({
  selector: 'tooltip-content',
  template:
  `
      <div class="pos" [ngStyle]="{top: positionX }">

            <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
            viewBox="0 0 100.8 63.8" enable-background="new 0 0 100.8 63.8" xml:space="preserve">
            <path fill="#FFFFFF" stroke="#A7A9AC" stroke-width="0.5" stroke-miterlimit="10" d="M0.6,1.5l0.1,52.7c0,0.3,0.3,0.6,0.6,0.6
              l71,0.1c0.2,0,0.4,0.1,0.5,0.3l4,6.3c0.3,0.4,0.8,0.4,1.1,0l3.4-6.2c0.1-0.2,0.3-0.3,0.5-0.3h17.1c0.3,0,0.6-0.3,0.6-0.6V1.5
              c0-0.3-0.3-0.6-0.6-0.6H1.3C0.9,0.9,0.6,1.2,0.6,1.5z"/>
            <line fill="none" stroke="#A7A9AC" stroke-width="0.5" stroke-miterlimit="10" x1="0.8" y1="13.8" x2="99.6" y2="13.8"/>
            <text x="5" y="10" font-size="4pt" font-weight="bold" text-anchor="left" fill="#808080"> AVGNAME<tspan x="70" font-weight="bold">ID {{position}}</tspan></text>
            <text x="5" y="22" font-size="4pt" text-anchor="left" fill="#808080">Type  <tspan x="50" font-weight="bold">{{position}}</tspan></text>
            <text x="5" y="30" font-size="4pt" text-anchor="left" fill="#808080">Serial Number <tspan x="50" font-weight="bold">{{position}}</tspan></text>
            <text x="5" y="38" font-size="4pt" text-anchor="left" fill="#808080">Mounted Robot <tspan x="50"font-weight="bold">{{position}}</tspan></text>
            <text x="5" y="46" font-size="4pt" text-anchor="left" fill="#808080">Type <tspan x="60" font-weight="bold">Protected</tspan></text>
            <image xlink:href="./assets/mobile-robotics/safe-protected_sm.svg" x="50" y="40" height="7px" width="7px"></image> 
            
            </svg>

    </div>
  `,
  styles: [
    `
          svg{
              width: 200px;
              /*overflow: hidden;*/
          }
          .pos{ 
              position: absolute;
              z-index: 20000; 
          }
  `],
})
export class TooltipComponent implements AfterViewInit, OnInit{
  @Input() title: string;
  @Input() ref: any;
  position: any;
  icn = "./assets/KMP/safe-protected_sm.svg";
  
  ngAfterViewInit(): void {
    // position based on `ref`
    //this.position = this.ref.nativeElement.getBoundingClientRect()["top"];
    //this.ref.nativeElement.style["top"] = (this.position + 60).toString() + "px";
    //console.log(this.position);
  }
  ngOnInit():void{
    this.position = parseInt(this.ref.nativeElement.getBoundingClientRect()["top"]);
  }

  @HostListener('window:resize')
  onWindowResize(): void {
    // update position based on `ref`
   
  }
}
